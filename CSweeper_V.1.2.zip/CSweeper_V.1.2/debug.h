//
// Created by matth on 11/22/2023.
//

#ifndef CSWEEPER_V_1_1_4_DEBUG_H
#define CSWEEPER_V_1_1_4_DEBUG_H
void values(int grid[][30],int limit1,int limit2);

//REVEAL CODE VISIBILITY------------------------------------------------------------------------------------------------
void reveal(int hidden[][30],int limit1,int limit2);

//REVEAL CODE GAME------------------------------------------------------------------------------------------------------
void reveal_game(int grid[][30],int limit1,int limit2);

#endif //CSWEEPER_V_1_1_4_DEBUG_H
