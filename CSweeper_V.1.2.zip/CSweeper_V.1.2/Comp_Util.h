//
// Created by matth on 11/22/2023.
//

#ifndef CSWEEPER_V_1_1_4_COMP_UTIL_H
#define CSWEEPER_V_1_1_4_COMP_UTIL_H
#if _WIN32 || _WIN64
    //DONT INCLUDE
#else
#include <iostream>
#include <string>
#include "CSweeper.h"
void update(int[][30],int[][30],std::string[][31],int,int);
void view(std::string[][31],int,int,int);
void scoreboard(stats);
#endif
#endif //CSWEEPER_V_1_1_4_COMP_UTIL_H
