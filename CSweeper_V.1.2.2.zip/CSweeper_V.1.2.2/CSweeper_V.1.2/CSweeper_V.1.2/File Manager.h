//
// Created by matth on 11/28/2023.
//

#ifndef CSWEEPER_V_1_1_4_FILE_MANAGER_H
#define CSWEEPER_V_1_1_4_FILE_MANAGER_H
#include <string>
void leaderboard(std::string,int,bool);
void display();
#endif //CSWEEPER_V_1_1_4_FILE_MANAGER_H
