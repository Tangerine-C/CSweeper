//
// Created by matth on 12/4/2023.
//

#ifndef CSWEEPER_V_1_2_OUTPUT_H
#define CSWEEPER_V_1_2_OUTPUT_H
#include <iostream>
#include <string>
#include "CSweeper.h"
void update(int[][30],int[][30],std::string[][31],int,int);
void view(std::string[][31],int,int,int);
void scoreboard(stats);
#if _WIN64 || _WIN32
#include <windows.h> //REQUIRED FOR HANDLE RETURN AND ACQUISITION
HANDLE getHandle();
void ResetColoring();
void colorCode(const std::string[][31],int,int);
#else
//Don't include
#endif
#endif //CSWEEPER_V_1_2_OUTPUT_H
