//
// Created by matth on 12/4/2023.
//

#ifndef CSWEEPER_V_1_2_INPUT_H
#define CSWEEPER_V_1_2_INPUT_H
#include <iostream>
#include <string>
template<typename input>
input clean(input);
std::string input_state();
int input_x(int);
int input_y(int);
#endif //CSWEEPER_V_1_2_INPUT_H
